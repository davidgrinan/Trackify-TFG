package com.example.trackify.controller;

import com.example.trackify.dto.Contenido.ContenidoDTO;
import com.example.trackify.dto.Contenido.RequestContenidoDTO;
import com.example.trackify.exceptions.Response;
import com.example.trackify.service.contenido.IContenidoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ContenidoController {

    private final IContenidoService contenidoService;

    public ContenidoController(IContenidoService contenidoService) {
        this.contenidoService = contenidoService;
    }

    @GetMapping("/contenidos")
    public ResponseEntity<List<ContenidoDTO>> listarTodos() {
        return ResponseEntity.ok(contenidoService.listarTodos());
    }

    @GetMapping("/usuarios/{usuarioId}/contenidos")
    public ResponseEntity<List<ContenidoDTO>> listarPorUsuario(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(contenidoService.listarPorUsuario(usuarioId));
    }

    @GetMapping("/contenidos/{id}")
    public ResponseEntity<ContenidoDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(contenidoService.obtenerPorId(id));
    }

    @GetMapping("/usuarios/{usuarioId}/contenidos/filtrar")
    public ResponseEntity<List<ContenidoDTO>> filtrarPorUsuario(@PathVariable Long usuarioId,
                                                               @RequestParam(required = false) String tipo,
                                                               @RequestParam(required = false) String genero,
                                                               @RequestParam(required = false) String estado,
                                                               @RequestParam(required = false) Integer valoracion) {
        return ResponseEntity.ok(contenidoService.filtrarPorUsuario(usuarioId, tipo, genero, estado, valoracion));
    }

    @GetMapping("/usuarios/{usuarioId}/contenidos/buscar")
    public ResponseEntity<List<ContenidoDTO>> buscarPorTitulo(@PathVariable Long usuarioId,
                                                             @RequestParam String titulo) {
        return ResponseEntity.ok(contenidoService.buscarPorTitulo(usuarioId, titulo));
    }

    @PostMapping("/usuarios/{usuarioId}/contenidos")
    public ResponseEntity<ContenidoDTO> crear(@PathVariable Long usuarioId,
                                             @Valid @RequestBody RequestContenidoDTO requestContenidoDTO) {
        return new ResponseEntity<>(contenidoService.crear(usuarioId, requestContenidoDTO), HttpStatus.CREATED);
    }

    @PutMapping("/contenidos/{id}")
    public ResponseEntity<ContenidoDTO> actualizar(@PathVariable Long id,
                                                  @Valid @RequestBody RequestContenidoDTO requestContenidoDTO) {
        return ResponseEntity.ok(contenidoService.actualizar(id, requestContenidoDTO));
    }

    @DeleteMapping("/contenidos/{id}")
    public ResponseEntity<Response> eliminar(@PathVariable Long id) {
        contenidoService.eliminar(id);
        return ResponseEntity.ok(Response.ok("Contenido eliminado correctamente"));
    }
}
