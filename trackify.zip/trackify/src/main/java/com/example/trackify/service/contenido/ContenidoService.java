package com.example.trackify.service.contenido;

import com.example.trackify.dto.Contenido.ContenidoDTO;
import com.example.trackify.dto.Contenido.RequestContenidoDTO;
import com.example.trackify.entity.Contenido;
import com.example.trackify.entity.Estado;
import com.example.trackify.entity.Genero;
import com.example.trackify.entity.Tipo;
import com.example.trackify.entity.Usuario;
import com.example.trackify.exceptions.CreateEntityException;
import com.example.trackify.exceptions.DeleteEntityException;
import com.example.trackify.exceptions.NotFoundEntityException;
import com.example.trackify.exceptions.UpdateEntityException;
import com.example.trackify.mapper.ContenidoMapper;
import com.example.trackify.repository.Contenido.IContenidoRepository;
import com.example.trackify.repository.Estado.IEstadoRepository;
import com.example.trackify.repository.Genero.IGeneroRepository;
import com.example.trackify.repository.Tipo.ITipoRepository;
import com.example.trackify.repository.Usuario.IUsuarioRepository;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class ContenidoService implements IContenidoService {

    private final IContenidoRepository contenidoRepository;
    private final IUsuarioRepository usuarioRepository;
    private final IGeneroRepository generoRepository;
    private final ITipoRepository tipoRepository;
    private final IEstadoRepository estadoRepository;
    private final ContenidoMapper contenidoMapper;

    private final Logger logger = LoggerFactory.getLogger(ContenidoService.class);

    @Override
    public List<ContenidoDTO> listarPorUsuario(Long usuarioId) {

        logger.info("Listando contenidos del usuario {}", usuarioId);

        validarUsuario(usuarioId);

        List<Contenido> contenidos =
                contenidoRepository.listarContenidoPorUsuario(usuarioId);

        return contenidoMapper.toDTOList(contenidos);
    }

    @Override
    public ContenidoDTO obtenerPorId(Long id) {

        logger.info("Buscando contenido con id {}", id);

        Contenido contenido = contenidoRepository.findById(id)
                .orElseThrow(() ->
                        new NotFoundEntityException(
                                "Contenido con id " + id + " no encontrado"
                        ));

        return contenidoMapper.toDTO(contenido);
    }

    @Override
    public List<ContenidoDTO> filtrarPorUsuario(Long usuarioId,
                                                String tipo,
                                                String genero,
                                                String estado,
                                                Integer valoracion) {

        logger.info("Filtrando contenidos del usuario {}", usuarioId);

        validarUsuario(usuarioId);

        List<Contenido> contenidos =
                contenidoRepository.filtrarContenidoPorUsuario(
                        usuarioId,
                        limpiarTexto(tipo),
                        limpiarTexto(genero),
                        limpiarTexto(estado),
                        valoracion
                );

        return contenidoMapper.toDTOList(contenidos);
    }

    @Override
    public List<ContenidoDTO> buscarPorTitulo(Long usuarioId, String titulo) {

        logger.info("Buscando contenido por titulo {} del usuario {}",
                titulo,
                usuarioId
        );

        validarUsuario(usuarioId);

        List<Contenido> contenidos =
                contenidoRepository.buscarContenidoPorTitulo(
                        usuarioId,
                        limpiarTexto(titulo)
                );

        return contenidoMapper.toDTOList(contenidos);
    }

    @Override
    public ContenidoDTO crear(Long usuarioId,
                              RequestContenidoDTO requestContenidoDTO) {

        logger.info("Intento de crear contenido");

        try {

            Usuario usuario = validarUsuario(usuarioId);

            Contenido contenido =
                    contenidoMapper.toEntity(requestContenidoDTO);

            contenido.setUsuario(usuario);

            asignarRelaciones(contenido, requestContenidoDTO);

            contenido = contenidoRepository.save(contenido);

            logger.info("Contenido creado correctamente");

            return contenidoMapper.toDTO(contenido);

        } catch (Exception ex) {

            logger.error("Error creando contenido", ex);

            throw new CreateEntityException(
                    Contenido.class.getSimpleName(),
                    requestContenidoDTO,
                    ex
            );
        }
    }

    @Override
    public ContenidoDTO actualizar(Long id,
                                   RequestContenidoDTO requestContenidoDTO) {

        logger.info("Intento de actualizar contenido {}", id);

        try {

            Contenido contenido = contenidoRepository.findById(id)
                    .orElseThrow(() ->
                            new NotFoundEntityException(
                                    "Contenido con id " + id + " no encontrado"
                            ));

            contenidoMapper.updateEntityFromDTO(
                    requestContenidoDTO,
                    contenido
            );

            asignarRelaciones(contenido, requestContenidoDTO);

            contenido = contenidoRepository.save(contenido);

            logger.info("Contenido actualizado correctamente");

            return contenidoMapper.toDTO(contenido);

        } catch (Exception ex) {

            logger.error("Error actualizando contenido {}", id, ex);

            throw new UpdateEntityException(
                    Contenido.class.getSimpleName(),
                    requestContenidoDTO,
                    ex
            );
        }
    }

    @Override
    public void eliminar(Long id) {

        logger.info("Intento de eliminar contenido {}", id);

        try {

            Contenido contenido = contenidoRepository.findById(id)
                    .orElseThrow(() ->
                            new NotFoundEntityException("Contenido con id " + id + " no encontrado"));

            contenidoRepository.delete(contenido);

            logger.info("Contenido eliminado correctamente");

        } catch (Exception ex) {

            logger.error("Error eliminando contenido {}", id, ex);

            throw new DeleteEntityException(
                    Contenido.class.getSimpleName(),
                    id,
                    ex
            );
        }
    }

    private Usuario validarUsuario(Long usuarioId) {

        return usuarioRepository.findById(usuarioId)
                .orElseThrow(() ->
                        new NotFoundEntityException(
                                "Usuario con id " + usuarioId + " no encontrado"
                        ));
    }

    private void asignarRelaciones(Contenido contenido,
                                   RequestContenidoDTO requestContenidoDTO) {

        Genero genero = generoRepository
                .findByNombre(requestContenidoDTO.getGenero())
                .orElseThrow(() ->
                        new NotFoundEntityException(
                                "Genero "
                                        + requestContenidoDTO.getGenero()
                                        + " no encontrado"
                        ));

        Tipo tipo = tipoRepository
                .findByNombre(requestContenidoDTO.getTipo())
                .orElseThrow(() ->
                        new NotFoundEntityException(
                                "Tipo "
                                        + requestContenidoDTO.getTipo()
                                        + " no encontrado"
                        ));

        Estado estado = estadoRepository
                .findByNombre(requestContenidoDTO.getEstado())
                .orElseThrow(() ->
                        new NotFoundEntityException(
                                "Estado "
                                        + requestContenidoDTO.getEstado()
                                        + " no encontrado"
                        ));

        contenido.setGenero(genero);
        contenido.setTipo(tipo);
        contenido.setEstado(estado);
    }

    private String limpiarTexto(String texto) {

        if (texto == null || texto.isBlank()) {
            return null;
        }

        return texto.trim();
    }
}