package com.example.trackify.config;

import com.example.trackify.config.security.JwtAccessDenied;
import com.example.trackify.config.security.JwtAuthenticationFilter;
import com.example.trackify.config.security.JwtEntryPoint;
import com.example.trackify.service.usuario.IUsuarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final JwtEntryPoint jwtEntryPoint;
    private final JwtAccessDenied jwtAccessDenied;
    private final IUsuarioService usuarioService;
    
    @Bean
    public UserDetailsService userDetailsService() {
        return usuarioService::loadUserByUsername;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(jwtEntryPoint)
                        .accessDeniedHandler(jwtAccessDenied))
                .authorizeHttpRequests(auth -> auth

                        .requestMatchers("/auth/**").permitAll().anyRequest().authenticated()
                        .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll().anyRequest().authenticated()

                        .requestMatchers("/api/contenido/**").hasRole("USER")
                        .requestMatchers("/api/estados/**").hasAnyRole("USER", "ADMIN")
                        .requestMatchers("/api/genero/**").hasAnyRole("USER", "ADMIN")
                        .requestMatchers("/api/tipo/**").hasAnyRole("USER", "ADMIN")
                )
                .userDetailsService(userDetailsService())
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}