package com.example.trackify.service.contenido;

import com.example.trackify.dto.Contenido.ContenidoDTO;
import com.example.trackify.dto.Contenido.RequestContenidoDTO;

import java.util.List;

public interface IContenidoService {

    /**
     * Lista todos los contenidos de un usuario
     */
    List<ContenidoDTO> listarPorUsuario(Long usuarioId);

    /**
     * Obtiene un contenido por su id
     */
    ContenidoDTO obtenerPorId(Long id);

    /**
     * Filtra contenidos de un usuario
     */
    List<ContenidoDTO> filtrarPorUsuario(Long usuarioId,
                                         String tipo,
                                         String genero,
                                         String estado,
                                         Integer valoracion);

    /**
     * Busca contenidos por título
     */
    List<ContenidoDTO> buscarPorTitulo(Long usuarioId,
                                       String titulo);

    /**
     * Crea un nuevo contenido
     */
    ContenidoDTO crear(Long usuarioId,
                       RequestContenidoDTO requestContenidoDTO);

    /**
     * Actualiza un contenido existente
     */
    ContenidoDTO actualizar(Long id,
                            RequestContenidoDTO requestContenidoDTO);

    /**
     * Elimina un contenido
     */
    void eliminar(Long id);
}